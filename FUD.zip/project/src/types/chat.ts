export interface Message {
  id: string;
  content: string;
  sender: 'user' | 'bot';
  timestamp: Date;
  type?: 'text' | 'quick-actions' | 'course-info' | 'admission-info';
}

export interface QuickAction {
  id: string;
  label: string;
  query: string;
  icon?: string;
}

export interface UserProfile {
  id: string;
  name: string;
  type: 'prospective' | 'current' | 'alumni' | 'staff';
  department?: string;
  level?: string;
}

export interface CourseInfo {
  code: string;
  title: string;
  department: string;
  credits: number;
  description: string;
  prerequisites?: string[];
  level: string;
}

export interface AdmissionRequirement {
  program: string;
  department: string;
  requirements: string[];
  cutoffMark?: number;
  duration: string;
}

export interface ChatContext {
  lastIntent?: string;
  userProfile?: UserProfile;
  conversationHistory: Message[];
  currentTopic?: string;
}