import React from 'react';
import { QuickAction } from '../types/chat';
import { BookOpen, GraduationCap, CreditCard, Calendar, Home, Monitor } from 'lucide-react';

interface QuickActionsProps {
  actions: QuickAction[];
  onActionClick: (query: string) => void;
}

const iconMap = {
  BookOpen,
  GraduationCap,
  CreditCard,
  Calendar,
  Home,
  Monitor,
};

export const QuickActions: React.FC<QuickActionsProps> = ({ actions, onActionClick }) => {
  return (
    <div className="mb-4">
      <p className="text-sm text-gray-600 mb-3 px-4">Quick actions to get you started:</p>
      <div className="grid grid-cols-2 gap-2 px-4">
        {actions.map((action) => {
          const IconComponent = iconMap[action.icon as keyof typeof iconMap];
          
          return (
            <button
              key={action.id}
              onClick={() => onActionClick(action.query)}
              className="flex items-center gap-2 p-3 text-left border border-gray-200 rounded-lg hover:border-blue-300 hover:bg-blue-50 transition-all duration-200 group"
            >
              {IconComponent && (
                <IconComponent size={16} className="text-blue-600 group-hover:text-blue-700" />
              )}
              <span className="text-sm font-medium text-gray-700 group-hover:text-blue-700">
                {action.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};