import React from 'react';
import { UserProfile } from '../types/chat';
import { GraduationCap, BookOpen, Users, Briefcase } from 'lucide-react';

interface UserTypeSelectorProps {
  onSelectUserType: (userType: UserProfile['type']) => void;
}

const userTypes = [
  {
    type: 'prospective' as const,
    label: 'Prospective Student',
    description: 'Looking to apply to FUD',
    icon: GraduationCap,
    color: 'blue',
  },
  {
    type: 'current' as const,
    label: 'Current Student',
    description: 'Currently enrolled at FUD',
    icon: BookOpen,
    color: 'green',
  },
  {
    type: 'alumni' as const,
    label: 'Alumni',
    description: 'FUD graduate',
    icon: Users,
    color: 'purple',
  },
  {
    type: 'staff' as const,
    label: 'Staff/Faculty',
    description: 'FUD employee',
    icon: Briefcase,
    color: 'orange',
  },
];

export const UserTypeSelector: React.FC<UserTypeSelectorProps> = ({ onSelectUserType }) => {
  return (
    <div className="p-6 bg-white rounded-lg shadow-sm border border-gray-200">
      <h3 className="text-lg font-semibold text-gray-900 mb-2">Welcome to FUD AI Assistant</h3>
      <p className="text-gray-600 mb-6">To provide you with the most relevant information, please select your status:</p>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {userTypes.map((userType) => {
          const IconComponent = userType.icon;
          
          return (
            <button
              key={userType.type}
              onClick={() => onSelectUserType(userType.type)}
              className={`p-4 border-2 border-gray-200 rounded-lg hover:border-${userType.color}-300 hover:bg-${userType.color}-50 transition-all duration-200 text-left group`}
            >
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 bg-${userType.color}-100 rounded-lg flex items-center justify-center group-hover:bg-${userType.color}-200 transition-colors`}>
                  <IconComponent size={20} className={`text-${userType.color}-600`} />
                </div>
                <div>
                  <h4 className="font-medium text-gray-900">{userType.label}</h4>
                  <p className="text-sm text-gray-500">{userType.description}</p>
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};