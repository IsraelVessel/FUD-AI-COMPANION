import React from 'react';
import { MessageCircle, BookOpen, Users, Shield, Clock } from 'lucide-react';

interface WelcomeScreenProps {
  onGetStarted: () => void;
}

export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ onGetStarted }) => {
  const features = [
    {
      icon: BookOpen,
      title: 'Course Information',
      description: 'Get detailed information about all available courses and programs',
    },
    {
      icon: Users,
      title: 'Admission Guidance',
      description: 'Learn about admission requirements and application procedures',
    },
    {
      icon: Shield,
      title: 'University Policies',
      description: 'Access important university policies and academic regulations',
    },
    {
      icon: Clock,
      title: '24/7 Support',
      description: 'Get instant answers to your questions anytime, anywhere',
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50 flex items-center justify-center p-4">
      <div className="max-w-4xl w-full">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <MessageCircle size={32} className="text-white" />
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-2">FUD AI Assistant</h1>
          <p className="text-xl text-gray-600 mb-4">Your intelligent guide to Federal University Dutse</p>
          <p className="text-gray-500 max-w-2xl mx-auto">
            Get instant, accurate information about courses, admissions, policies, and more. 
            Our AI-powered chatbot is designed to provide personalized support for all your university needs.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {features.map((feature, index) => (
            <div 
              key={index}
              className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow duration-300"
            >
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                <feature.icon size={24} className="text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>

        <div className="text-center">
          <button
            onClick={onGetStarted}
            className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-full font-semibold transition-colors duration-200 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 transition-all"
          >
            Start Chatting
          </button>
          <p className="text-sm text-gray-500 mt-4">
            Available 24/7 • Powered by advanced AI • Instant responses
          </p>
        </div>
      </div>
    </div>
  );
};