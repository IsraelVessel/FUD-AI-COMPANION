import React from 'react';
import { MessageCircle, Users, Clock } from 'lucide-react';

interface ChatHeaderProps {
  onlineUsers?: number;
  responseTime?: string;
}

export const ChatHeader: React.FC<ChatHeaderProps> = ({ 
  onlineUsers = 247, 
  responseTime = "< 1 sec" 
}) => {
  return (
    <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white p-4 rounded-t-lg">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
            <MessageCircle size={20} />
          </div>
          <div>
            <h2 className="font-semibold text-lg">FUD AI Assistant</h2>
            <p className="text-blue-100 text-sm">Federal University Dutse Support</p>
          </div>
        </div>
        
        <div className="text-right text-sm">
          <div className="flex items-center gap-1 text-blue-100">
            <Users size={14} />
            <span>{onlineUsers} online</span>
          </div>
          <div className="flex items-center gap-1 text-blue-100 mt-1">
            <Clock size={14} />
            <span>Avg response: {responseTime}</span>
          </div>
        </div>
      </div>
      
      <div className="mt-3 flex items-center gap-2">
        <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
        <span className="text-sm text-blue-100">AI Assistant is online and ready to help</span>
      </div>
    </div>
  );
};