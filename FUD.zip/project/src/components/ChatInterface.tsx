import React, { useState, useEffect, useRef } from 'react';
import { Message, UserProfile } from '../types/chat';
import { ChatMessage } from './ChatMessage';
import { ChatInput } from './ChatInput';
import { ChatHeader } from './ChatHeader';
import { QuickActions } from './QuickActions';
import { UserTypeSelector } from './UserTypeSelector';
import { ChatService } from '../services/chatService';
import { quickActions } from '../data/knowledgeBase';

export const ChatInterface: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [showQuickActions, setShowQuickActions] = useState(true);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatService = useRef(new ChatService());

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(scrollToBottom, [messages, isTyping]);

  const addMessage = (content: string, sender: 'user' | 'bot') => {
    const newMessage: Message = {
      id: Date.now().toString(),
      content,
      sender,
      timestamp: new Date(),
    };
    setMessages(prev => [...prev, newMessage]);
  };

  const handleSendMessage = async (messageContent: string) => {
    if (!userProfile) return;
    
    addMessage(messageContent, 'user');
    setIsLoading(true);
    setIsTyping(true);
    setShowQuickActions(false);

    // Simulate API delay for realistic feel
    await new Promise(resolve => setTimeout(resolve, 800 + Math.random() * 1200));

    try {
      const response = await chatService.current.processMessage(messageContent);
      setIsTyping(false);
      
      // Add slight delay before showing response
      await new Promise(resolve => setTimeout(resolve, 300));
      addMessage(response, 'bot');
    } catch (error) {
      setIsTyping(false);
      addMessage('I apologize, but I encountered an error. Please try again or contact our support team for assistance.', 'bot');
    } finally {
      setIsLoading(false);
    }
  };

  const handleUserTypeSelection = (userType: UserProfile['type']) => {
    const profile: UserProfile = {
      id: Date.now().toString(),
      name: 'Student',
      type: userType,
    };
    
    setUserProfile(profile);
    
    const welcomeMessage = getWelcomeMessage(userType);
    addMessage(welcomeMessage, 'bot');
  };

  const handleQuickAction = (query: string) => {
    handleSendMessage(query);
  };

  const getWelcomeMessage = (userType: UserProfile['type']): string => {
    switch (userType) {
      case 'prospective':
        return "Welcome to FUD! I'm excited to help you learn about our programs and admission process. I can provide information about courses, requirements, fees, and campus life. What would you like to know?";
      case 'current':
        return "Hello! As a current FUD student, I can help you with course registration, academic policies, hostel information, portal access, and more. How can I assist you today?";
      case 'alumni':
        return "Welcome back, FUD alumnus! I can help you with alumni services, transcripts, certificates, and university updates. What information do you need?";
      case 'staff':
        return "Hello! I can provide information about university policies, student services, academic programs, and administrative procedures. How may I assist you?";
      default:
        return "Welcome to FUD AI Assistant! How can I help you today?";
    }
  };

  if (!userProfile) {
    return (
      <div className="max-w-2xl mx-auto bg-gray-50 min-h-screen flex items-center justify-center p-4">
        <UserTypeSelector onSelectUserType={handleUserTypeSelection} />
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto bg-gray-50 min-h-screen flex flex-col">
      <ChatHeader />
      
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {showQuickActions && messages.length <= 1 && (
          <QuickActions actions={quickActions} onActionClick={handleQuickAction} />
        )}
        
        {messages.map((message) => (
          <ChatMessage key={message.id} message={message} />
        ))}
        
        {isTyping && (
          <ChatMessage 
            message={{
              id: 'typing',
              content: '',
              sender: 'bot',
              timestamp: new Date(),
            }}
            isTyping={true}
          />
        )}
        
        <div ref={messagesEndRef} />
      </div>
      
      <ChatInput 
        onSendMessage={handleSendMessage} 
        isLoading={isLoading}
        placeholder="Ask me anything about FUD..."
      />
    </div>
  );
};