import { Message } from '../types/chat';

export const generateMessageId = (): string => {
  return `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
};

export const formatTimestamp = (date: Date): string => {
  return date.toLocaleTimeString([], { 
    hour: '2-digit', 
    minute: '2-digit',
    hour12: true 
  });
};

export const searchMessages = (messages: Message[], query: string): Message[] => {
  const lowercaseQuery = query.toLowerCase();
  return messages.filter(message => 
    message.content.toLowerCase().includes(lowercaseQuery)
  );
};

export const getContextualSuggestions = (lastMessage: string): string[] => {
  const suggestions: Record<string, string[]> = {
    course: [
      "Tell me more about Computer Science courses",
      "What are the prerequisites for this course?",
      "Show me courses in other departments",
    ],
    admission: [
      "What documents do I need for application?",
      "When is the application deadline?",
      "How do I prepare for Post-UTME?",
    ],
    fees: [
      "Are there payment plans available?",
      "What about scholarship opportunities?",
      "Tell me about additional fees",
    ],
    default: [
      "Tell me about course registration",
      "How do I access the student portal?",
      "What are the hostel facilities like?",
    ],
  };

  const lowerMessage = lastMessage.toLowerCase();
  
  if (lowerMessage.includes('course')) return suggestions.course;
  if (lowerMessage.includes('admission')) return suggestions.admission;
  if (lowerMessage.includes('fee')) return suggestions.fees;
  
  return suggestions.default;
};

export const simulateTypingDelay = (messageLength: number): number => {
  // Simulate realistic typing speed (40-60 WPM)
  const wordsPerMinute = 50;
  const charactersPerMinute = wordsPerMinute * 5; // Average 5 characters per word
  const millisecondsPerCharacter = 60000 / charactersPerMinute;
  
  return Math.min(Math.max(messageLength * millisecondsPerCharacter, 500), 3000);
};