import { courses, admissionRequirements, universityPolicies, faqs } from '../data/knowledgeBase';
import { Message, ChatContext } from '../types/chat';

export class ChatService {
  private context: ChatContext;

  constructor() {
    this.context = {
      conversationHistory: [],
      currentTopic: undefined,
    };
  }

  async processMessage(userMessage: string): Promise<string> {
    const intent = this.detectIntent(userMessage);
    const response = await this.generateResponse(userMessage, intent);
    
    this.updateContext(userMessage, intent);
    return response;
  }

  private detectIntent(message: string): string {
    const lowerMessage = message.toLowerCase();
    
    // Course-related intents
    if (lowerMessage.includes('course') || lowerMessage.includes('subject') || lowerMessage.includes('csc') || lowerMessage.includes('mth')) {
      return 'course_inquiry';
    }
    
    // Admission-related intents
    if (lowerMessage.includes('admission') || lowerMessage.includes('requirement') || lowerMessage.includes('apply') || lowerMessage.includes('entry')) {
      return 'admission_inquiry';
    }
    
    // Fees-related intents
    if (lowerMessage.includes('fee') || lowerMessage.includes('cost') || lowerMessage.includes('payment') || lowerMessage.includes('money')) {
      return 'fees_inquiry';
    }
    
    // Hostel/accommodation intents
    if (lowerMessage.includes('hostel') || lowerMessage.includes('accommodation') || lowerMessage.includes('room')) {
      return 'accommodation_inquiry';
    }
    
    // Academic calendar intents
    if (lowerMessage.includes('calendar') || lowerMessage.includes('session') || lowerMessage.includes('semester') || lowerMessage.includes('start')) {
      return 'calendar_inquiry';
    }
    
    // Portal access intents
    if (lowerMessage.includes('portal') || lowerMessage.includes('login') || lowerMessage.includes('access') || lowerMessage.includes('registration')) {
      return 'portal_inquiry';
    }
    
    // Policy intents
    if (lowerMessage.includes('policy') || lowerMessage.includes('rule') || lowerMessage.includes('regulation')) {
      return 'policy_inquiry';
    }
    
    // Greeting intents
    if (lowerMessage.includes('hello') || lowerMessage.includes('hi') || lowerMessage.includes('hey') || lowerMessage.includes('good')) {
      return 'greeting';
    }
    
    return 'general_inquiry';
  }

  private async generateResponse(message: string, intent: string): Promise<string> {
    switch (intent) {
      case 'greeting':
        return this.getGreetingResponse();
      
      case 'course_inquiry':
        return this.getCourseResponse(message);
      
      case 'admission_inquiry':
        return this.getAdmissionResponse(message);
      
      case 'fees_inquiry':
        return this.getFeesResponse();
      
      case 'accommodation_inquiry':
        return this.getAccommodationResponse();
      
      case 'calendar_inquiry':
        return this.getCalendarResponse();
      
      case 'portal_inquiry':
        return this.getPortalResponse();
      
      case 'policy_inquiry':
        return this.getPolicyResponse();
      
      default:
        return this.getGeneralResponse(message);
    }
  }

  private getGreetingResponse(): string {
    return "Hello! Welcome to FUD AI Assistant. I'm here to help you with information about Federal University Dutse including courses, admission requirements, policies, and more. How can I assist you today?";
  }

  private getCourseResponse(message: string): string {
    const lowerMessage = message.toLowerCase();
    
    // Check for specific course codes
    const courseCode = lowerMessage.match(/([a-z]{3}\d{3})/i);
    if (courseCode) {
      const course = courses.find(c => c.code.toLowerCase() === courseCode[0].toLowerCase());
      if (course) {
        return `**${course.code} - ${course.title}**\n\n📚 **Department:** ${course.department}\n🎯 **Credits:** ${course.credits}\n📖 **Description:** ${course.description}\n📊 **Level:** ${course.level} Level${course.prerequisites ? `\n⚠️ **Prerequisites:** ${course.prerequisites.join(', ')}` : ''}`;
      }
    }
    
    // Check for department-specific queries
    if (lowerMessage.includes('computer science') || lowerMessage.includes('csc')) {
      const csCourses = courses.filter(c => c.department === 'Computer Science');
      return `Here are some Computer Science courses available at FUD:\n\n${csCourses.map(c => `• **${c.code}** - ${c.title} (${c.credits} credits)`).join('\n')}\n\nWould you like detailed information about any specific course?`;
    }
    
    return "FUD offers a wide range of undergraduate and postgraduate programs across various faculties including Physical Sciences, Life Sciences, Social Sciences, Education, and more. Which specific course or department would you like to know about?";
  }

  private getAdmissionResponse(message: string): string {
    const lowerMessage = message.toLowerCase();
    
    if (lowerMessage.includes('computer science') || lowerMessage.includes('csc')) {
      const csReq = admissionRequirements.find(r => r.program === 'Computer Science');
      if (csReq) {
        return `**Computer Science Admission Requirements:**\n\n${csReq.requirements.map(req => `• ${req}`).join('\n')}\n\n📊 **JAMB Cut-off:** ${csReq.cutoffMark}\n⏱️ **Duration:** ${csReq.duration}\n\n💡 **Tip:** Ensure all requirements are met before applying!`;
      }
    }
    
    if (lowerMessage.includes('medicine') || lowerMessage.includes('mbbs')) {
      const medReq = admissionRequirements.find(r => r.program === 'Medicine and Surgery');
      if (medReq) {
        return `**Medicine and Surgery Admission Requirements:**\n\n${medReq.requirements.map(req => `• ${req}`).join('\n')}\n\n📊 **JAMB Cut-off:** ${medReq.cutoffMark}\n⏱️ **Duration:** ${medReq.duration}\n\n⚠️ **Note:** Medicine is highly competitive with very strict requirements.`;
      }
    }
    
    return "FUD admission is through JAMB and Post-UTME screening. General requirements include:\n\n• Minimum of 5 O'Level credits including English and Mathematics\n• Appropriate JAMB score for your chosen course\n• Successful Post-UTME screening\n\nWhich specific program are you interested in?";
  }

  private getFeesResponse(): string {
    return "**FUD School Fees Structure (2024/2025 Session):**\n\n💰 **Undergraduate Programs:**\n• Arts/Social Sciences: ₦45,000 - ₦55,000\n• Sciences: ₦55,000 - ₦65,000\n• Medicine: ₦85,000 - ₦95,000\n• Engineering: ₦65,000 - ₦75,000\n\n📋 **Additional Fees:**\n• Acceptance Fee: ₦25,000 (one-time)\n• Hostel Accommodation: ₦35,000 - ₦45,000\n• Registration Fee: ₦5,000\n\n💡 **Payment Methods:** Bank transfer, online payment, or designated banks. Contact the bursary department for detailed breakdown.";
  }

  private getAccommodationResponse(): string {
    return "**FUD Hostel Accommodation:**\n\n🏠 **Available Hostels:**\n• Male hostels: 4 blocks with modern facilities\n• Female hostels: 3 blocks with 24/7 security\n\n📋 **Allocation Process:**\n• Online application through student portal\n• Payment of accommodation fees required\n• Priority given to final year students and distant states\n\n💰 **Fees:** ₦35,000 - ₦45,000 per session\n⏰ **Visiting Hours:** 8:00 AM - 6:00 PM\n\n🔧 **Facilities:** Study rooms, kitchenettes, laundry areas, common rooms\n\nWould you like help with the application process?";
  }

  private getCalendarResponse(): string {
    return "**FUD Academic Calendar 2024/2025:**\n\n📅 **Key Dates:**\n• Registration for New Students: October 15 - November 15, 2024\n• Registration for Returning Students: September 20 - October 20, 2024\n• First Semester: October 2024 - February 2025\n• First Semester Exams: January - February 2025\n• Second Semester: March - July 2025\n• Second Semester Exams: June - July 2025\n\n🎓 **Special Events:**\n• Orientation Week: October 7-11, 2024\n• Matriculation Ceremony: November 2024\n• Convocation: December 2025\n\n⚠️ **Note:** Dates may be subject to change. Check the university website for updates.";
  }

  private getPortalResponse(): string {
    return "**FUD Student Portal Access:**\n\n🌐 **Portal URL:** portal.fud.edu.ng\n\n👤 **Login Credentials:**\n• Username: Your student ID number\n• Password: Default is your surname (change after first login)\n\n⚙️ **Portal Features:**\n• Course registration\n• Result checking\n• Fee payment\n• Hostel application\n• Academic records\n• Timetable access\n\n🔧 **Troubleshooting:**\n• Clear browser cache if login fails\n• Contact ICT helpdesk for password reset\n• Use updated browsers (Chrome, Firefox, Safari)\n\n💡 **Tip:** Always logout after use and keep your credentials secure!";
  }

  private getPolicyResponse(): string {
    const policies = Object.values(universityPolicies);
    return `**FUD University Policies:**\n\n${policies.map(policy => 
      `**${policy.title}:**\n${policy.items.map(item => `• ${item}`).join('\n')}`
    ).join('\n\n')}\n\nNeed more details about any specific policy? Just ask!`;
  }

  private getGeneralResponse(message: string): string {
    // Try to find relevant FAQ
    const relevantFaq = faqs.find(faq => 
      faq.question.toLowerCase().includes(message.toLowerCase()) ||
      message.toLowerCase().includes(faq.question.toLowerCase().split(' ')[0])
    );
    
    if (relevantFaq) {
      return `**${relevantFaq.question}**\n\n${relevantFaq.answer}`;
    }
    
    return "I understand you're looking for information about FUD. I can help you with:\n\n• Course information and requirements\n• Admission procedures and requirements\n• School fees and payment methods\n• Hostel accommodation\n• Academic calendar and important dates\n• University policies\n• Student portal access\n\nPlease let me know what specific information you need!";
  }

  private updateContext(message: string, intent: string): void {
    this.context.lastIntent = intent;
    this.context.currentTopic = intent;
  }

  getQuickActionsForContext(): string[] {
    const contextActions = [
      "Tell me about Computer Science courses",
      "What are the admission requirements for Medicine?",
      "How much is the school fees?",
      "Show me the academic calendar",
    ];
    
    return contextActions;
  }
}