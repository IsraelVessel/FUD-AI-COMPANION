import React, { useState } from 'react';
import { ChatInterface } from './components/ChatInterface';
import { WelcomeScreen } from './components/WelcomeScreen';

function App() {
  const [showChat, setShowChat] = useState(false);

  const handleGetStarted = () => {
    setShowChat(true);
  };

  if (!showChat) {
    return <WelcomeScreen onGetStarted={handleGetStarted} />;
  }

  return <ChatInterface />;
}

export default App;