import { CourseInfo, AdmissionRequirement } from '../types/chat';

export const courses: CourseInfo[] = [
  {
    code: 'CSC101',
    title: 'Introduction to Computer Science',
    department: 'Computer Science',
    credits: 3,
    description: 'Basic concepts of computer science including programming fundamentals, algorithms, and data structures.',
    level: '100',
  },
  {
    code: 'MTH101',
    title: 'Elementary Mathematics I',
    department: 'Mathematics',
    credits: 3,
    description: 'Fundamental mathematical concepts including algebra, trigonometry, and basic calculus.',
    level: '100',
  },
  {
    code: 'ENG101',
    title: 'Use of English I',
    department: 'English',
    credits: 2,
    description: 'English language skills development focusing on reading, writing, and communication.',
    level: '100',
  },
  {
    code: 'BIO201',
    title: 'General Biology',
    department: 'Biological Sciences',
    credits: 4,
    description: 'Introduction to biological principles, cell biology, genetics, and ecology.',
    prerequisites: ['BIO101'],
    level: '200',
  },
  {
    code: 'CHE201',
    title: 'Organic Chemistry',
    department: 'Chemistry',
    credits: 4,
    description: 'Study of organic compounds, their structures, properties, and reactions.',
    prerequisites: ['CHE101', 'CHE102'],
    level: '200',
  },
];

export const admissionRequirements: AdmissionRequirement[] = [
  {
    program: 'Computer Science',
    department: 'Physical Sciences',
    requirements: [
      'Five (5) O\'Level credits including Mathematics, English Language, Physics',
      'Two (2) A\'Level credits in Mathematics and Physics',
      'JAMB score of 200 and above',
      'Post-UTME screening test',
    ],
    cutoffMark: 200,
    duration: '4 years',
  },
  {
    program: 'Medicine and Surgery',
    department: 'Medical Sciences',
    requirements: [
      'Five (5) O\'Level credits including Mathematics, English Language, Physics, Chemistry, Biology',
      'Three (3) A\'Level credits in Physics, Chemistry, and Biology',
      'JAMB score of 280 and above',
      'Post-UTME screening test',
      'Medical fitness certificate',
    ],
    cutoffMark: 280,
    duration: '6 years',
  },
  {
    program: 'Economics',
    department: 'Social Sciences',
    requirements: [
      'Five (5) O\'Level credits including Mathematics, English Language',
      'Two (2) A\'Level credits including Mathematics or Economics',
      'JAMB score of 180 and above',
      'Post-UTME screening test',
    ],
    cutoffMark: 180,
    duration: '4 years',
  },
];

export const universityPolicies = {
  academic: {
    title: 'Academic Policies',
    items: [
      'Minimum CGPA of 1.50 required to remain in good academic standing',
      'Maximum of 8 years allowed to complete a 4-year degree program',
      'Attendance requirement: minimum 75% for all courses',
      'Late registration incurs additional fees',
      'Grade point system: A=5, B=4, C=3, D=2, F=0',
    ],
  },
  student_conduct: {
    title: 'Student Conduct',
    items: [
      'Academic integrity must be maintained at all times',
      'Plagiarism and cheating result in disciplinary action',
      'Respectful behavior towards staff and fellow students required',
      'Dress code must be observed on campus',
      'Use of mobile phones during lectures is prohibited',
    ],
  },
  accommodation: {
    title: 'Accommodation Policies',
    items: [
      'Hostel allocation based on level and availability',
      'Payment of accommodation fees required before allocation',
      'Visiting hours: 8:00 AM to 6:00 PM',
      'No cooking in rooms - use designated kitchen areas',
      'Damage to hostel property will be charged to student',
    ],
  },
};

export const faqs = [
  {
    question: 'How do I check my admission status?',
    answer: 'You can check your admission status by logging into the FUD admission portal using your JAMB registration number and password. Results are typically available 2-3 weeks after the Post-UTME screening.',
  },
  {
    question: 'What is the school fees structure?',
    answer: 'School fees vary by faculty and level. Generally, fees range from ₦45,000 to ₦65,000 per session for undergraduate programs. Medical students pay higher fees. Check the bursary department for detailed breakdown.',
  },
  {
    question: 'How do I register for courses?',
    answer: 'Course registration is done online through the student portal. Login with your student ID and password, select your courses for the semester, and print your course registration form for submission to your department.',
  },
  {
    question: 'When does the academic session begin?',
    answer: 'The academic session typically begins in October for fresh students and September for returning students. Check the academic calendar on the university website for exact dates.',
  },
  {
    question: 'How do I apply for hostel accommodation?',
    answer: 'Hostel applications are made online through the student portal. Payment of accommodation fees is required before allocation. Priority is given to students from distant states and final year students.',
  },
];

export const quickActions = [
  { id: '1', label: 'Course Information', query: 'Tell me about available courses', icon: 'BookOpen' },
  { id: '2', label: 'Admission Requirements', query: 'What are the admission requirements?', icon: 'GraduationCap' },
  { id: '3', label: 'School Fees', query: 'How much is the school fees?', icon: 'CreditCard' },
  { id: '4', label: 'Academic Calendar', query: 'When does the session start?', icon: 'Calendar' },
  { id: '5', label: 'Hostel Information', query: 'Tell me about accommodation', icon: 'Home' },
  { id: '6', label: 'Student Portal', query: 'How do I access the student portal?', icon: 'Monitor' },
];